#include <stdio.h>
#include <conio.h>
void main()
{
clrscr();
gotoxy(10,10);
printf("hola mundo");
getch();
}